/** Published copy of this policy. */
export const PRIVACY_POLICY_URL = 'https://sites.google.com/view/kikitips/home';

export const privacyUpdated = '25 October 2026';

export const privacySections: { title: string; body: string }[] = [
  {
    title: 'Who we are',
    body: 'Kiki Tips publishes free technology stories at https://yerase.com. This policy covers the Kiki Tips app on Android and iOS, and those public stories. It is effective 25 October 2026.',
  },
  {
    title: 'What the app does',
    body: 'The app shows public stories from yerase.com. You can read them, save them on your device, share a story link, choose a light or dark appearance, and turn on an alert when a new story is published. The app is free, in English, and does not ask you to create an account. To stay free, the app shows advertisements from Google AdMob.',
  },
  {
    title: 'Information stored on your device',
    body: 'Saved articles, your appearance choice, whether new-story alerts are on, and the list of story alerts already shown are stored on your device. Kiki Tips uses this information only to run those features. It is not sent to yerase.com. Uninstalling the app, or clearing the app storage, removes it.',
  },
  {
    title: 'New-story alerts',
    body: 'If you leave new-story alerts on, the app asks the phone for permission to show notifications. When a story is published on yerase.com, the app alerts you. Where the phone supports it, the app also sends a device notification token and the platform, such as Android or iOS, to yerase.com so the site can deliver that alert. The token is not your name, phone number, or email. Turning alerts off asks the site to delete that token.',
  },
  {
    title: 'Stories and images',
    body: 'The app loads public story text and photos from yerase.com over an encrypted connection. Those requests include the ordinary technical information a web server receives, such as an IP address, so the site can send the story to the app.',
  },
  {
    title: 'Advertising',
    body: 'Google AdMob serves the ads in this app. Google may process an advertising ID, other device identifiers, an IP address, and information about ads shown or tapped, such as the time and the rough interaction. Google uses that information to deliver ads, measure them, fight fraud, and cap how often an ad is shown. Where the law requires a choice, including in the European Economic Area, the United Kingdom, and regulated US states, the app asks before using data for ads that are based on your activity across other apps and websites. If you say no, or if you have not been asked yet, the app can still show ads that are not based on that activity. Kiki Tips does not receive your name, phone number, or email address from Google. Google describes its own handling at https://policies.google.com/privacy and https://policies.google.com/technologies/ads. Ad choices can be changed in the phone settings. Where the law requires it, this Privacy Policy screen also offers Ad privacy choices.',
  },
  {
    title: 'Permissions',
    body: 'Notifications: the app asks for this permission only so it can alert you when a new story is published. You can deny it and keep reading. Advertising ID: on Android, Google Play services provides an advertising ID to AdMob. Kiki Tips does not show a separate prompt for that ID. App tracking: on iPhone, the app may ask for permission to use an identifier for ads across other companies’ apps and websites. Declining does not block the stories. The app does not request your location, contacts, camera, microphone, photos, or SMS.',
  },
  {
    title: 'What we do not do',
    body: 'Kiki Tips does not sell personal information. The app does not ask you to create an account, and it does not use a separate analytics product. It does not ask for your contacts, precise location, camera, microphone, or photos.',
  },
  {
    title: 'Children',
    body: 'Kiki Tips is a general-audience technology publication. It is not directed at children under 13, and we do not knowingly collect personal information from them. Ad requests are not tagged as child-directed. If you believe a child has provided personal information, contact us through https://yerase.com and we will delete the notification token if we hold one.',
  },
  {
    title: 'Your choices',
    body: 'You can turn new-story alerts off in Profile, then Notifications. You can also turn off notifications for Kiki Tips in the phone settings. Saved articles can be removed with the bookmark button. On Android, you can reset or delete the advertising ID in the phone settings. On iPhone, you can decline tracking, or turn off Allow Apps to Request to Track. Where Ad privacy choices appears on this screen, you can reopen the ad consent choice. You can stop using the app and delete it at any time. A request to delete a notification token can be sent through https://yerase.com.',
  },
  {
    title: 'Changes',
    body: 'If this policy changes, the updated version will appear in the app and at https://sites.google.com/view/kikitips/home. The date above will change with it. Continued use of the app after the update means the new policy applies.',
  },
  {
    title: 'Contact',
    body: 'Questions about this policy, or a request to delete a notification token, can be sent through https://yerase.com.',
  },
];
